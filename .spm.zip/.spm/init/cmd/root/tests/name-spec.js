define(function(require) {

  var {%= varName %} = require('../src/{%= name %}');

  describe('{%= name %}', function() {

    it('normal usage', function() {

    });
  });

});
