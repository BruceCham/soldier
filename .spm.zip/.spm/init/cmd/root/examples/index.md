# Demo

---

## Normal usage

````javascript
seajs.use('{%= name %}', function({%= varName %}) {

});
````
