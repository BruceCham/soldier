define(function(require, exports, module) {

  var {%= varName %};

  module.exports = {%= varName %};

});
