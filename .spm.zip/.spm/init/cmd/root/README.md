# {%= name %}

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="{%= family %}-{%= name %}">
</div>
````

```javascript
seajs.use('{%= name %}', function({%= varName %}) {

});
```

## Api

Here is some details.
